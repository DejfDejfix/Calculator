﻿
using System.Data;

namespace Kalkulačka_Projekt
{
    class Calculator
    {
        public void Calculate(DisplayControler displayControler)
        {

            string calculation = displayControler.DisplayCalculation;

            DataTable dt = new DataTable();

            try 
            {
                object Result = dt.Compute(calculation, "");
                displayControler.DisplayResult = Result.ToString();
            }
            catch
            {
                displayControler.DisplayResult = "Error";
                displayControler.DisplayCalculation = null;
            }
        }
    }
}
