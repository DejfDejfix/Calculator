﻿
using System.Windows;

namespace Kalkulačka_Projekt
{
    public partial class MainWindow : Window
    {

        //inicializace objektů pro logiku a okna
        DisplayControler displayControler = new DisplayControler();

        Calculator calculator = new Calculator();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = displayControler;
        }

        //Kliknutí tlačítek

        // 1-3
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("1");
            displayControler.CalculationChange("1");
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("2");
            displayControler.CalculationChange("1");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("3");
            displayControler.CalculationChange("1");
        }

        // 4-6
        private void button4_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("4");
            displayControler.CalculationChange("1");
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("5");
            displayControler.CalculationChange("1");
        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("6");
            displayControler.CalculationChange("1");
        }

        // 7-9
        private void button7_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("7");
            displayControler.CalculationChange("1");
        }

        private void button8_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("8");
            displayControler.CalculationChange("1");
        }

        private void button9_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("9");
            displayControler.CalculationChange("1");
        }

        // operace
        private void buttonMultiplication_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("*");
            displayControler.CalculationChange("1");
        }

        private void buttonDivision_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("/");
            displayControler.CalculationChange("1");
        }

        private void buttonAddition_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("+");
            displayControler.CalculationChange("1");
        }

        private void buttonSubstraction_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("-");
            displayControler.CalculationChange("1");
        }

        // = a clear
        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationClear();
            displayControler.displayResultClear();
            displayControler.calculationClear();
        }

        private void buttonCalculate_Click(object sender, RoutedEventArgs e)
        {
            calculator.Calculate(displayControler);
            displayControler.calculatedChange();
        }


        private void button0_Click_1(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("0");
            displayControler.CalculationChange("1");
        }

        private void buttonPoint_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange(".");
            displayControler.CalculationChange("1");
        }

        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            displayControler.delete();
        }

        private void buttonBraceStart_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("(");
            displayControler.CalculationChange("1");
        }

        private void buttonBraceEnd_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange(")");
            displayControler.CalculationChange("1");
        }

        private void buttonSquare_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("^2");
            displayControler.CalculationChange("^2");
        }
    }
}
