﻿
using System.Windows;

namespace Kalkulačka_Projekt
{
    public partial class MainWindow : Window
    {

        //inicializace objektů pro logiku a okna
        DisplayControler displayControler = new DisplayControler();

        Calculator calculator = new Calculator();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = displayControler;
        }

        //Kliknutí tlačítek

        // 1-3
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("1");
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("2");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("3");
        }

        // 4-6
        private void button4_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("4");
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("5");
        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("6");
        }

        // 7-9
        private void button7_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("7");
        }

        private void button8_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("8");
        }

        private void button9_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("9");
        }

        // operace
        private void buttonMultiplication_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("*");
        }

        private void buttonDivision_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("/");
        }

        private void buttonAddition_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("+");
        }

        private void buttonSubstraction_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("-");
        }

        // = a clear
        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            displayControler.calculationClear();
            displayControler.resultClear();
        }

        private void buttonCalculate_Click(object sender, RoutedEventArgs e)
        {
            calculator.Calculate(displayControler);
            displayControler.calculatedChange();
        }


        private void button0_Click_1(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("0");
        }

        private void buttonPoint_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange(".");
        }

        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            displayControler.delete();
        }

        private void buttonBraceStart_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange("(");
        }

        private void buttonBraceEnd_Click(object sender, RoutedEventArgs e)
        {
            displayControler.displayCalculationChange(")");
        }
    }
}
